import os
import re
import json
import time
import hashlib
import sqlite3
from collections import defaultdict, Counter
from difflib import SequenceMatcher

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# ============================================================
# Q2 - SETUBID TENDER DEDUPLICATION
# Covers A, B, C, D and E
# ============================================================

BASE = r"C:\Users\ub02-glab-050\Desktop\data_2\data_2"
OUT = r"C:\Users\ub02-glab-050\Desktop\Q2"

os.makedirs(OUT, exist_ok=True)
os.makedirs(os.path.join(OUT, "screenshots"), exist_ok=True)

print("=" * 75)
print("Q2 - SETUBID TENDER DEDUPLICATION")
print("=" * 75)


# ============================================================
# LOAD DATA
# ============================================================

files = [
    os.path.join(BASE, "notices", f"part-{i:03d}.csv")
    for i in range(8)
]

frames = []

for f in files:
    if os.path.exists(f):
        frames.append(pd.read_csv(f))

df = pd.concat(frames, ignore_index=True)

labels = pd.read_csv(
    os.path.join(BASE, "labelled_pairs.csv")
)

print("\n[DATA]")
print("Notices :", len(df))
print("Unique notice IDs :", df["notice_id"].nunique())
print("Portals :", df["portal_id"].nunique())

print("\n[LABEL SKEW]")
label_counts = labels["label"].value_counts()
print(label_counts.to_string())

same_count = int((labels["label"] == "same").sum())
different_count = int((labels["label"] == "different").sum())

print("Same :", same_count)
print("Different :", different_count)


# ============================================================
# TEXT NORMALIZATION
# ============================================================

def normalize_text(text):
    if pd.isna(text):
        return ""

    text = str(text).lower()

    # Known portal boilerplate
    phrases = [
        "national procurement aggregation service",
        "state procurement cell"
    ]

    for p in phrases:
        text = text.replace(p, " ")

    # Remove disclaimer footer
    text = re.sub(
        r"disclaimer.*$",
        " ",
        text,
        flags=re.I | re.S
    )

    text = re.sub(r"\s+", " ", text)

    return text.strip()


def word_tokens(text):
    return set(
        x for x in re.findall(r"[a-z0-9]{3,}", text)
    )


def char_3grams(text):
    text = re.sub(r"\s+", " ", normalize_text(text))
    return set(
        text[i:i+3]
        for i in range(max(0, len(text)-2))
    )


df["norm_title"] = df["title"].fillna("").apply(normalize_text)
df["norm_body"] = df["body"].fillna("").apply(normalize_text)

# Title is repeated to increase its influence.
df["representation"] = (
    df["norm_title"] + " " +
    df["norm_title"] + " " +
    df["norm_title"] + " " +
    df["norm_body"]
)

df["word_set"] = df["representation"].apply(word_tokens)


# ============================================================
# ID LOOKUP
# ============================================================

id_to_index = {
    notice_id: i
    for i, notice_id in enumerate(df["notice_id"])
}


# ============================================================
# SIMILARITY FUNCTIONS
# ============================================================

def jaccard(a, b):
    if not a and not b:
        return 1.0

    if not a or not b:
        return 0.0

    return len(a & b) / len(a | b)


def raw_char_similarity(a, b):
    return SequenceMatcher(
        None,
        normalize_text(a),
        normalize_text(b)
    ).ratio()


def weighted_similarity(a, b):

    title_score = SequenceMatcher(
        None,
        a["norm_title"],
        b["norm_title"]
    ).ratio()

    body_score = SequenceMatcher(
        None,
        a["norm_body"],
        b["norm_body"]
    ).ratio()

    value_score = 0.0

    try:
        va = float(a["estimated_value"])
        vb = float(b["estimated_value"])

        if va == vb:
            value_score = 1.0
        elif max(abs(va), abs(vb)) > 0:
            value_score = max(
                0,
                1 - abs(va - vb) / max(abs(va), abs(vb))
            )
    except Exception:
        pass

    # Closing date is deliberately NOT required to match:
    # a corrigendum may change it.

    return (
        0.60 * title_score +
        0.30 * body_score +
        0.10 * value_score
    )


# ============================================================
# A - COMPARE TWO REPRESENTATION CHOICES
# ============================================================

print("\n" + "=" * 75)
print("A - DEFINITION OF SIMILAR")
print("=" * 75)

evidence_pairs = [
    ("N010018", "N010020", "same"),
    ("N007876", "N008565", "different")
]

a_rows = []

for a_id, b_id, label in evidence_pairs:

    a = df.iloc[id_to_index[a_id]]
    b = df.iloc[id_to_index[b_id]]

    char_a = raw_char_similarity(
        a["body"],
        b["body"]
    )

    char_b = raw_char_similarity(
        a["title"],
        b["title"]
    )

    word_score = jaccard(
        a["word_set"],
        b["word_set"]
    )

    weighted = weighted_similarity(a, b)

    a_rows.append({
        "notice_a": a_id,
        "notice_b": b_id,
        "label": label,
        "character_body_similarity": char_a,
        "character_title_similarity": char_b,
        "word_jaccard": word_score,
        "weighted_score": weighted
    })

    print("\nPair:", a_id, "<->", b_id)
    print("Label:", label)
    print("Character body similarity:", round(char_a, 4))
    print("Character title similarity:", round(char_b, 4))
    print("Word Jaccard:", round(word_score, 4))
    print("Weighted score:", round(weighted, 4))

    print("A title:", a["title"])
    print("B title:", b["title"])
    print("A value:", a["estimated_value"])
    print("B value:", b["estimated_value"])
    print("A closing:", a["closing_date"])
    print("B closing:", b["closing_date"])


a_df = pd.DataFrame(a_rows)

a_df.to_csv(
    os.path.join(OUT, "A_similarity_evidence.csv"),
    index=False
)


# ============================================================
# B - FIXED REDUCED REPRESENTATION
# ============================================================

print("\n" + "=" * 75)
print("B - REDUCED REPRESENTATION")
print("=" * 75)

# Application requirement:
# keep a fixed 128-token sketch.
# This is fixed BEFORE evaluating the labels.

SKETCH_SIZE = 128

def hash_token(token):
    return int(
        hashlib.sha256(
            token.encode("utf-8")
        ).hexdigest(),
        16
    )


def sketch(tokens, size=SKETCH_SIZE):

    if not tokens:
        return set()

    hashes = sorted(
        hash_token(t)
        for t in tokens
    )

    return set(hashes[:size])


df["sketch"] = df["word_set"].apply(sketch)


def sketch_jaccard(a, b):
    return jaccard(a["sketch"], b["sketch"])


b_rows = []

for _, p in labels.iterrows():

    a = df.iloc[id_to_index[p["notice_id_a"]]]
    b = df.iloc[id_to_index[p["notice_id_b"]]]

    exact = jaccard(
        a["word_set"],
        b["word_set"]
    )

    estimated = sketch_jaccard(a, b)

    b_rows.append({
        "notice_id_a": p["notice_id_a"],
        "notice_id_b": p["notice_id_b"],
        "label": p["label"],
        "exact_similarity": exact,
        "estimated_similarity": estimated,
        "absolute_error": abs(exact - estimated)
    })

b_df = pd.DataFrame(b_rows)

print("Fixed sketch size :", SKETCH_SIZE)
print("Mean absolute error :",
      round(b_df["absolute_error"].mean(), 5))
print("Median absolute error :",
      round(b_df["absolute_error"].median(), 5))
print("95th percentile error :",
      round(
          b_df["absolute_error"].quantile(0.95),
          5
      ))
print("Maximum error :",
      round(b_df["absolute_error"].max(), 5))

b_df.to_csv(
    os.path.join(OUT, "B_representation_error.csv"),
    index=False
)


# ============================================================
# C - SUBLINEAR RETRIEVAL
# ============================================================

print("\n" + "=" * 75)
print("C - SUBLINEAR RETRIEVAL")
print("=" * 75)

# Build inverted index.
# Token -> notice IDs

inverted = defaultdict(set)

for i, token_set in enumerate(df["word_set"]):

    for token in token_set:
        inverted[token].add(i)

print("Index tokens :", len(inverted))

# Remove extremely common words.
MAX_FREQ = max(
    100,
    int(len(df) * 0.05)
)

common_tokens = {
    token
    for token, ids in inverted.items()
    if len(ids) > MAX_FREQ
}

print("Common tokens removed :", len(common_tokens))


# ------------------------------------------------------------
# Candidate retrieval with tunable K
# ------------------------------------------------------------

def retrieve_candidates(idx, k):

    token_counts = Counter()

    for token in df.iloc[idx]["word_set"]:

        if token in common_tokens:
            continue

        for other in inverted[token]:

            if other != idx:
                token_counts[other] += 1

    ranked = sorted(
        token_counts.items(),
        key=lambda x: x[1],
        reverse=True
    )

    return [
        x[0]
        for x in ranked[:k]
    ]


# Measure candidate survival for labelled pairs.
# Candidate K is the tunable work/recall setting.

K_VALUES = [10, 25, 50, 100, 200, 500]

c_rows = []

for k in K_VALUES:

    survives = 0
    total = 0

    for _, p in labels.iterrows():

        a_idx = id_to_index[p["notice_id_a"]]
        b_idx = id_to_index[p["notice_id_b"]]

        candidates = retrieve_candidates(
            a_idx,
            k
        )

        if b_idx in candidates:
            survives += 1

        total += 1

    survival = survives / total

    print(
        "K =", k,
        "| candidate survival =",
        round(survival, 4)
    )

    c_rows.append({
        "candidate_k": k,
        "survival_probability": survival
    })


c_df = pd.DataFrame(c_rows)

c_df.to_csv(
    os.path.join(OUT, "C_retrieval_curve.csv"),
    index=False
)


# ------------------------------------------------------------
# Retrieval probability as function of true similarity
# ------------------------------------------------------------

similarity_rows = []

K_OPERATING = 100

for _, p in labels.iterrows():

    a_idx = id_to_index[p["notice_id_a"]]
    b_idx = id_to_index[p["notice_id_b"]]

    a = df.iloc[a_idx]
    b = df.iloc[b_idx]

    true_similarity = weighted_similarity(a, b)

    candidates = retrieve_candidates(
        a_idx,
        K_OPERATING
    )

    survives = int(b_idx in candidates)

    similarity_rows.append({
        "label": p["label"],
        "true_similarity": true_similarity,
        "survives_candidate_stage": survives
    })


sim_df = pd.DataFrame(similarity_rows)

sim_df["similarity_bin"] = pd.cut(
    sim_df["true_similarity"],
    bins=[0, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1.0],
    include_lowest=True
)

curve_by_similarity = (
    sim_df
    .groupby("similarity_bin", observed=False)
    ["survives_candidate_stage"]
    .mean()
    .reset_index()
)

curve_by_similarity.to_csv(
    os.path.join(
        OUT,
        "C_survival_by_true_similarity.csv"
    ),
    index=False
)


# Plot C
plt.figure(figsize=(8, 5))

plt.plot(
    c_df["candidate_k"],
    c_df["survival_probability"],
    marker="o"
)

plt.axvline(
    K_OPERATING,
    linestyle="--",
    label="Operating K = 100"
)

plt.xlabel("Candidate list size K")
plt.ylabel("Probability pair survives candidate stage")
plt.title("Candidate Retrieval Trade-off")
plt.legend()
plt.grid(True)

plt.tight_layout()

plt.savefig(
    os.path.join(
        OUT,
        "C_retrieval_tradeoff.png"
    ),
    dpi=160
)

plt.close()


# ============================================================
# SIMILARITY THRESHOLD ANALYSIS
# ============================================================

print("\n[SIMILARITY THRESHOLDS]")

threshold_rows = []

for threshold in np.arange(
    0.1,
    1.0,
    0.1
):

    same = sim_df[
        sim_df["label"] == "same"
    ]

    different = sim_df[
        sim_df["label"] == "different"
    ]

    same_recall = (
        same["true_similarity"] >= threshold
    ).mean()

    false_merge_candidates = int(
        (
            different["true_similarity"]
            >= threshold
        ).sum()
    )

    threshold_rows.append({
        "threshold": round(threshold, 1),
        "same_recall": same_recall,
        "different_pairs_passing": false_merge_candidates
    })

threshold_df = pd.DataFrame(threshold_rows)

threshold_df.to_csv(
    os.path.join(
        OUT,
        "similarity_threshold_results.csv"
    ),
    index=False
)


# Risk asymmetry required by product.
FALSE_MERGE_COST = 10
MISSED_MERGE_COST = 1

print("\nRisk setting:")
print(
    "False merge : missed merge =",
    f"{FALSE_MERGE_COST}:{MISSED_MERGE_COST}"
)

print("Operating candidate K :", K_OPERATING)


# ============================================================
# D - RELATIONAL DATABASE
# ============================================================

print("\n" + "=" * 75)
print("D - PERSISTENT RELATIONAL DATABASE")
print("=" * 75)

db_path = os.path.join(
    OUT,
    "setubid_retrieval.db"
)

conn = sqlite3.connect(db_path)
cur = conn.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS notices (
    notice_id TEXT PRIMARY KEY,
    portal_id TEXT,
    title TEXT,
    body TEXT,
    estimated_value REAL,
    closing_date TEXT,
    norm_title TEXT,
    norm_body TEXT
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS opportunity_cards (
    opportunity_id TEXT PRIMARY KEY,
    canonical_signature TEXT UNIQUE,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS notice_members (
    notice_id TEXT PRIMARY KEY,
    opportunity_id TEXT NOT NULL
)
""")

cur.execute("""
CREATE INDEX IF NOT EXISTS idx_portal
ON notices(portal_id)
""")

cur.execute("""
CREATE INDEX IF NOT EXISTS idx_value
ON notices(estimated_value)
""")

cur.execute("""
CREATE INDEX IF NOT EXISTS idx_closing
ON notices(closing_date)
""")

rows = []

for _, r in df.iterrows():

    try:
        value = float(r["estimated_value"])
    except Exception:
        value = None

    rows.append((
        str(r["notice_id"]),
        str(r["portal_id"]),
        str(r["title"]),
        str(r["body"]),
        value,
        str(r["closing_date"]),
        str(r["norm_title"]),
        str(r["norm_body"])
    ))

cur.executemany("""
INSERT OR REPLACE INTO notices
VALUES (?, ?, ?, ?, ?, ?, ?, ?)
""", rows)

conn.commit()


# ------------------------------------------------------------
# Indexed lookup
# ------------------------------------------------------------

plan = cur.execute("""
EXPLAIN QUERY PLAN
SELECT notice_id, title
FROM notices
WHERE portal_id = ?
""", ("P001",)).fetchall()

print("\nPlanner path:")
for p in plan:
    print(p)

start = time.perf_counter()

indexed_rows = cur.execute("""
SELECT notice_id, title
FROM notices
WHERE portal_id = ?
""", ("P001",)).fetchall()

indexed_time = time.perf_counter() - start


# ------------------------------------------------------------
# Forced scan alternative
# ------------------------------------------------------------

start = time.perf_counter()

scan_rows = cur.execute("""
SELECT notice_id, title
FROM notices
WHERE substr(portal_id,1,4) = ?
""", ("P001",)).fetchall()

scan_time = time.perf_counter() - start

print("\nIndexed rows :", len(indexed_rows))
print("Indexed time :", round(indexed_time, 6), "seconds")

print("Forced scan rows :", len(scan_rows))
print("Forced scan time :", round(scan_time, 6), "seconds")


with open(
    os.path.join(OUT, "D_database_measurement.txt"),
    "w",
    encoding="utf-8"
) as f:

    f.write("Planner path:\n")

    for p in plan:
        f.write(str(p) + "\n")

    f.write(
        f"\nIndexed rows: {len(indexed_rows)}\n"
    )

    f.write(
        f"Indexed time: {indexed_time:.6f} seconds\n"
    )

    f.write(
        f"\nForced scan rows: {len(scan_rows)}\n"
    )

    f.write(
        f"Forced scan time: {scan_time:.6f} seconds\n"
    )


# ============================================================
# STABLE OPPORTUNITY IDS
# ============================================================

def canonical_signature(row):

    title = normalize_text(row["title"])

    try:
        value = round(
            float(row["estimated_value"]),
            2
        )
    except Exception:
        value = ""

    return f"{title}|{value}"


def stable_card_id(signature):

    return hashlib.sha256(
        signature.encode("utf-8")
    ).hexdigest()[:24]


cards = {}

for _, row in df.iterrows():

    sig = canonical_signature(row)

    if sig not in cards:
        cards[sig] = stable_card_id(sig)


for sig, card_id in cards.items():

    cur.execute("""
    INSERT OR IGNORE INTO opportunity_cards
    (opportunity_id, canonical_signature)
    VALUES (?, ?)
    """, (card_id, sig))


mapping = []

for _, row in df.iterrows():

    sig = canonical_signature(row)

    mapping.append((
        str(row["notice_id"]),
        cards[sig]
    ))

cur.executemany("""
INSERT OR REPLACE INTO notice_members
(notice_id, opportunity_id)
VALUES (?, ?)
""", mapping)

conn.commit()


# ============================================================
# E - HEAVY TAIL
# ============================================================

print("\n" + "=" * 75)
print("E - FULL CORPUS WORK DISTRIBUTION")
print("=" * 75)


# BEFORE MITIGATION:
# use every non-common token and allow all matching candidates.

def retrieve_before(idx):

    candidates = set()

    for token in df.iloc[idx]["word_set"]:

        if token in common_tokens:
            continue

        candidates.update(
            inverted[token]
        )

    candidates.discard(idx)

    return candidates


start = time.perf_counter()

before_counts = []

for idx in range(len(df)):

    before_counts.append(
        len(retrieve_before(idx))
    )

before_time = time.perf_counter() - start

before_np = np.array(before_counts)

print("\nBEFORE mitigation")
print("Mean :", round(before_np.mean(), 2))
print("Median :", round(np.median(before_np), 2))
print("P90 :", round(np.percentile(before_np, 90), 2))
print("P95 :", round(np.percentile(before_np, 95), 2))
print("P99 :", round(np.percentile(before_np, 99), 2))
print("Maximum :", int(before_np.max()))
print("Runtime :", round(before_time, 3), "seconds")


# ------------------------------------------------------------
# MITIGATION:
# Use only rare, informative tokens.
# Maximum token frequency = 0.5% of corpus.
# ------------------------------------------------------------

RARE_LIMIT = max(
    5,
    int(len(df) * 0.005)
)

rare_tokens = {
    token
    for token, ids in inverted.items()
    if len(ids) <= RARE_LIMIT
}

print("\nRare token limit :", RARE_LIMIT)
print("Rare tokens :", len(rare_tokens))


def retrieve_after(idx):

    token_counts = Counter()

    for token in df.iloc[idx]["word_set"]:

        if token not in rare_tokens:
            continue

        for other in inverted[token]:

            if other != idx:
                token_counts[other] += 1

    # Keep only candidates sharing at least two
    # informative tokens where possible.
    ranked = sorted(
        token_counts.items(),
        key=lambda x: x[1],
        reverse=True
    )

    return [
        other
        for other, count in ranked
        if count >= 1
    ][:K_OPERATING]


start = time.perf_counter()

after_counts = []

for idx in range(len(df)):

    after_counts.append(
        len(retrieve_after(idx))
    )

after_time = time.perf_counter() - start

after_np = np.array(after_counts)

print("\nAFTER mitigation")
print("Mean :", round(after_np.mean(), 2))
print("Median :", round(np.median(after_np), 2))
print("P90 :", round(np.percentile(after_np, 90), 2))
print("P95 :", round(np.percentile(after_np, 95), 2))
print("P99 :", round(np.percentile(after_np, 99), 2))
print("Maximum :", int(after_np.max()))
print("Runtime :", round(after_time, 3), "seconds")


# ------------------------------------------------------------
# Retrieval quality before / after on labels
# ------------------------------------------------------------

before_survive = 0
after_survive = 0

for _, p in labels.iterrows():

    a_idx = id_to_index[p["notice_id_a"]]
    b_idx = id_to_index[p["notice_id_b"]]

    if b_idx in retrieve_before(a_idx):
        before_survive += 1

    if b_idx in retrieve_after(a_idx):
        after_survive += 1


before_recall = before_survive / len(labels)
after_recall = after_survive / len(labels)

print("\nRetrieval quality on 900 labelled pairs")
print("Before mitigation :", round(before_recall, 4))
print("After mitigation  :", round(after_recall, 4))


# ------------------------------------------------------------
# Save distribution
# ------------------------------------------------------------

distribution = pd.DataFrame({
    "notice_id": df["notice_id"],
    "portal_id": df["portal_id"],
    "before_candidates": before_counts,
    "after_candidates": after_counts
})

distribution.to_csv(
    os.path.join(
        OUT,
        "E_before_after_distribution.csv"
    ),
    index=False
)


# Plot heavy-tail comparison

plt.figure(figsize=(9, 5))

plt.plot(
    np.sort(before_np)[::-1],
    label="Before mitigation"
)

plt.plot(
    np.sort(after_np)[::-1],
    label="After mitigation"
)

plt.xlabel("Notice rank")
plt.ylabel("Candidate count")
plt.title("Retrieval Work Distribution Before and After Mitigation")
plt.legend()
plt.grid(True)

plt.tight_layout()

plt.savefig(
    os.path.join(
        OUT,
        "E_heavy_tail_before_after.png"
    ),
    dpi=160
)

plt.close()


# ============================================================
# PORTAL WORK
# ============================================================

portal_distribution = (
    distribution
    .groupby("portal_id")
    .agg(
        notices=("notice_id", "count"),
        before_mean=("before_candidates", "mean"),
        after_mean=("after_candidates", "mean"),
        before_max=("before_candidates", "max"),
        after_max=("after_candidates", "max")
    )
    .sort_values(
        "before_mean",
        ascending=False
    )
)

portal_distribution.to_csv(
    os.path.join(
        OUT,
        "E_portal_work_distribution.csv"
    )
)

print("\nTop portal volumes:")
print(
    df["portal_id"]
    .value_counts()
    .head(15)
    .to_string()
)


# ============================================================
# 20-MINUTE BUDGET
# ============================================================

BUDGET_SECONDS = 20 * 60

print("\n" + "=" * 75)
print("20-MINUTE BUDGET")
print("=" * 75)

print("Budget :", BUDGET_SECONDS, "seconds")
print("Before runtime :", round(before_time, 3))
print("After runtime :", round(after_time, 3))

print(
    "Before within budget :",
    before_time <= BUDGET_SECONDS
)

print(
    "After within budget :",
    after_time <= BUDGET_SECONDS
)


# ============================================================
# FINAL SUMMARY
# ============================================================

summary = {
    "corpus": {
        "notices": int(len(df)),
        "unique_notice_ids": int(df["notice_id"].nunique()),
        "portals": int(df["portal_id"].nunique())
    },

    "labels": {
        "total": int(len(labels)),
        "same": same_count,
        "different": different_count,
        "same_fraction": same_count / len(labels),
        "different_fraction": different_count / len(labels)
    },

    "A_similarity": {
        "representation": "normalized word tokens with title weighted 3x",
        "score": "0.60 title + 0.30 body + 0.10 estimated-value agreement",
        "closing_date_equal_required": False,
        "boilerplate_removed": True
    },

    "B_reduced_representation": {
        "fixed_sketch_size": SKETCH_SIZE,
        "mean_absolute_error": float(
            b_df["absolute_error"].mean()
        ),
        "median_absolute_error": float(
            b_df["absolute_error"].median()
        ),
        "p95_absolute_error": float(
            b_df["absolute_error"].quantile(.95)
        )
    },

    "C_retrieval": {
        "operating_candidate_k": K_OPERATING,
        "false_merge_cost": FALSE_MERGE_COST,
        "missed_merge_cost": MISSED_MERGE_COST,
        "cost_ratio": "10:1"
    },

    "D_database": {
        "database": "SQLite",
        "indexed_query_seconds": indexed_time,
        "forced_scan_seconds": scan_time,
        "indexed_rows": len(indexed_rows),
        "forced_scan_rows": len(scan_rows)
    },

    "E_heavy_tail": {
        "before_mean": float(before_np.mean()),
        "before_median": float(np.median(before_np)),
        "before_p95": float(np.percentile(before_np, 95)),
        "before_p99": float(np.percentile(before_np, 99)),
        "before_max": int(before_np.max()),
        "before_runtime_seconds": before_time,

        "after_mean": float(after_np.mean()),
        "after_median": float(np.median(after_np)),
        "after_p95": float(np.percentile(after_np, 95)),
        "after_p99": float(np.percentile(after_np, 99)),
        "after_max": int(after_np.max()),
        "after_runtime_seconds": after_time,

        "label_recall_before": before_recall,
        "label_recall_after": after_recall
    },

    "stable_cards": int(len(cards))
}


with open(
    os.path.join(OUT, "q2_summary.json"),
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        summary,
        f,
        indent=2
    )


# ============================================================
# CLOSE DATABASE
# ============================================================

conn.close()


print("\n" + "=" * 75)
print("Q2 COMPLETE")
print("=" * 75)

print("\nOutput folder:")
print(OUT)

print("\nGenerated evidence:")
print("A_similarity_evidence.csv")
print("B_representation_error.csv")
print("C_retrieval_curve.csv")
print("C_survival_by_true_similarity.csv")
print("C_retrieval_tradeoff.png")
print("similarity_threshold_results.csv")
print("D_database_measurement.txt")
print("E_before_after_distribution.csv")
print("E_portal_work_distribution.csv")
print("E_heavy_tail_before_after.png")
print("q2_summary.json")
print("setubid_retrieval.db")

print("\nStable opportunity cards :", len(cards))

print("=" * 75)